package barracksWars.core;

import barracksWars.core.commands.AddCommand;
import barracksWars.core.commands.FightCommand;
import barracksWars.core.commands.ReportCommand;
import barracksWars.data.UnitRepository;
import barracksWars.interfaces.*;
import barracksWars.interfaces.Runnable;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class Engine implements Runnable {

	private Repository repository;
	private UnitFactory unitFactory;

	public Engine(Repository repository, UnitFactory unitFactory) {
		this.repository = repository;
		this.unitFactory = unitFactory;
	}

	@Override
	public void run() {
		BufferedReader reader = new BufferedReader(
				new InputStreamReader(System.in));
		while (true) {
			try {
				String input = reader.readLine();
				String[] data = input.split("\\s+");
				String commandName = data[0];
				String result = interpretCommand(data, commandName);
				if (result.equals("fight")) {
					break;
				}
				System.out.println(result);
			} catch (RuntimeException e) {
				System.out.println(e.getMessage());
			} catch (IOException | ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
	}

	private String interpretCommand(String[] data, String commandName) throws ClassNotFoundException {

		try {
			Class<?> clazz = Class.forName(classCorreectName(commandName));
			Constructor<?> ctor = clazz.getDeclaredConstructor(String[].class,Repository.class, UnitFactory.class);
			Object obj = ctor.newInstance(data,this.repository,this.unitFactory);
			if (obj instanceof Executable){
				return ((Executable)obj).execute();
			}
		}catch (ClassNotFoundException
				| NoSuchMethodException
				| IllegalAccessException
				| InstantiationException
				| InvocationTargetException e){
			e.printStackTrace();
		}
		return null;
	}

	private String classCorreectName(String commandName) {
		String subs = commandName.substring(1);
		String command = Character.toUpperCase(commandName.charAt(0)) + subs;
		return "barracksWars.core.commands." + command + "Command";
	}

}
