package cresla;

import cresla.entities.io.Input;

public class Main {
    public static void main(String[] args) {

        Input input = new Input();
        input.readLine();

    }
}
