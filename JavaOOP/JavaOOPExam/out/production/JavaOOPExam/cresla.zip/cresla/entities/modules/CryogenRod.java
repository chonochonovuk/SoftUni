package cresla.entities.modules;

public class CryogenRod extends EnergyModules {

   public CryogenRod(int id,int cryoProductionIndex) {
        super(id,cryoProductionIndex);
    }
}
