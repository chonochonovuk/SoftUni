package cresla.entities.modules;



public class HeatProcessor extends AbsorberModules {
    public HeatProcessor(int id, int heatAbsorbing) {
        super(id,heatAbsorbing);
    }
}
