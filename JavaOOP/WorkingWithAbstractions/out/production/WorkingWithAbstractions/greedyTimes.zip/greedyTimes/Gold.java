package greedyTimes;

public class Gold {
    private long value = 0;

    public void addValue(long value){
        this.value += value;
    }
    public long getValue() {
        return this.value;
    }
}
